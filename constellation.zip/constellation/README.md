# Constellation

A Pen created on CodePen.

Original URL: [https://codepen.io/DevAgnihotri/pen/emNaEJq](https://codepen.io/DevAgnihotri/pen/emNaEJq).

Simulates a nice constellation on canvas